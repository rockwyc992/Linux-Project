#include <stdio.h>

#define TOTAL_ITERATION_NUM  100000000

int main()
{
    int i;
    int j;
    for(i = 1; i <= TOTAL_ITERATION_NUM; i++)
    { 
        for(j = 1; j <= TOTAL_ITERATION_NUM; j++)
        {
            //do nothing
        }
    }
    return 0;
}
